# Bye Bye Edge! One Command Line Edition
Bye Bye Edge! Uninstall Microsoft Edge with one command line!

## Disclaimer
WHAT YOU RUN ON YOUR MACHINE IS YOUR RESPONSIBILITY. MAKE SURE TO HAVE AN ALTERNATIVE BROWSER INSTALLED SUCH AS BRAVE OR FIREFOX BEFORE PROCEEDING.

## Compatibility
- Microsoft Edge preinstalled in the system
- Microsoft Edge installed system-wide
- EDGE ENTERPRISE IS NOT SUPPORTED BY THE SCRIPT.
## Running the script (Method 1)
Really one command!
1. Press Windows key and R at the same time
2. Type ```powershell irm https://shorturl.at/rzE6E | iex``` on the run box (don't irm blindly, [audit the script](https://shorturl.at/rzE6E) before running the command, I'm not doing anything bad!)
3. Press enter and wait for the script to finish (UAC prompt might appear, click yes)

## Running the script (Method 2)
It's easy! Follow those easy steps:
1. Open powershell
2. Type ```irm https://shorturl.at/rzE6E | iex``` (don't irm blindly, [audit the script](https://shorturl.at/rzE6E) before running the command, I'm not doing anything bad!)
3. Wait for the script to uninstall Edge on your system (UAC prompt might appear, click yes)
4. Enjoy :)

## Rights
Thanks to [ShadowWhisperer](https://github.com/ShadowWhisperer) for his [Uninstall Edge script](https://github.com/ShadowWhisperer/Remove-MS-Edge) as I took some code from him.
